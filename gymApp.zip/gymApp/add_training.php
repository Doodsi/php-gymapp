<?php
require_once 'config/database.php';
require_once 'classes/Training.php';

session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['uloga'] !== 'trener') {
    die("Pristup samo za trenere.");
}

$database = new Database();
$db = $database->connect();
$training = new Training($db);
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naziv = $_POST['naziv'];
    $opis = $_POST['opis'];
    $datum = $_POST['datum'];
    $vrijeme = $_POST['vrijeme'];
    $trener_id = $_SESSION['user']['id'];

    if ($training->create($naziv, $opis, $datum, $vrijeme, $trener_id)) {
        $message = "Trening uspješno dodan.";
    } else {
        $message = "Greška pri dodavanju.";
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Novi trening</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h2 class="mt-4">Dodaj trening</h2>
    <form method="POST">
        <input class="form-control my-2" type="text" name="naziv" placeholder="Naziv" required>
        <textarea class="form-control my-2" name="opis" placeholder="Opis"></textarea>
        <input class="form-control my-2" type="date" name="datum" required>
        <input class="form-control my-2" type="time" name="vrijeme" required>
        <button class="btn btn-primary" type="submit">Dodaj trening</button>
    </form>
    <p class="mt-3"><?= htmlspecialchars($message) ?></p>
</body>
</html>
