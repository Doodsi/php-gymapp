<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

require_once 'db.php';

try {
    $stmt = $pdo->query("SELECT w.id, u.name AS korisnik, w.workout_date, w.description, w.duration_minutes
                         FROM workouts w
                         JOIN users u ON w.user_id = u.id
                         ORDER BY w.workout_date DESC");

    echo "<h1>Raspored treninga</h1><table border='1' cellpadding='8'>";
    echo "<tr><th>Korisnik</th><th>Datum</th><th>Opis</th><th>Trajanje (min)</th></tr>";

    while ($row = $stmt->fetch()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['korisnik']) . "</td>";
        echo "<td>" . htmlspecialchars($row['workout_date']) . "</td>";
        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
        echo "<td>" . htmlspecialchars($row['duration_minutes']) . "</td>";
        echo "</tr>";
    }

    echo "</table><br><a href='logout.php'>Odjava</a>";

} catch (PDOException $e) {
    echo "Greška: " . $e->getMessage();
}
?>


<hr>
<nav>
    <a href="dashboard.php">📋 Raspored</a> |
    <a href="trainers.php">🏋️‍♂️ Treneri</a> |
    <a href="user_trainer.php">🔗 Veze korisnik–trener</a> |
    <a href="add_workout.php">➕ Dodaj trening</a> |
    <a href="logout.php">🚪 Odjava</a>
</nav>

<br><br>
<a href="home.php">⬅️ Natrag na početnu</a>