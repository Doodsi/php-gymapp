<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

$page = $_GET['page'] ?? 'home';
$validPages = ['home', 'dashboard', 'trainers', 'user_trainer', 'add_workout', 'logout'];

if (!in_array($page, $validPages)) {
    $page = 'home';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gym App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('https://images.unsplash.com/photo-1554284126-aa88f22d8b74') no-repeat center center fixed;
            background-size: cover;
            color: white;
        }
        .container {
            background-color: rgba(0,0,0,0.7);
            padding: 2rem;
            border-radius: 10px;
            margin-top: 2rem;
        }
        nav a.nav-link.active {
            font-weight: bold;
            color: #f8f9fa !important;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="?page=home">GymApp</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link <?= $page=='home'?'active':'' ?>" href="?page=home">Početna</a></li>
                <li class="nav-item"><a class="nav-link <?= $page=='dashboard'?'active':'' ?>" href="?page=dashboard">Raspored</a></li>
                <li class="nav-item"><a class="nav-link <?= $page=='add_workout'?'active':'' ?>" href="?page=add_workout">Dodaj trening</a></li>
                <li class="nav-item"><a class="nav-link <?= $page=='trainers'?'active':'' ?>" href="?page=trainers">Treneri</a></li>
                <li class="nav-item"><a class="nav-link <?= $page=='user_trainer'?'active':'' ?>" href="?page=user_trainer">Veze</a></li>
            </ul>
            <span class="navbar-text me-3">
                Prijavljen: <?= htmlspecialchars($_SESSION['user']['name']) ?>
            </span>
            <a class="btn btn-outline-light" href="?page=logout">Odjava</a>
        </div>
    </div>

    <button onclick="toggleDarkMode()" class="btn btn-outline-light ms-2">🌙/☀️</button>
</nav>

<div class="container">
    <?php include $page . '.php'; ?>
</div>


<script>
function toggleDarkMode() {
    document.body.classList.toggle('bg-dark');
    document.body.classList.toggle('text-light');
    document.querySelector('.container').classList.toggle('bg-dark');
    document.querySelector('.container').classList.toggle('text-light');
}
</script>

</body>
</html>
