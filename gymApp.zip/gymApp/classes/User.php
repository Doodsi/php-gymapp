<?php
class User {
    private $conn;
    private $table = "users";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function register($ime, $prezime, $email, $lozinka) {
        $sql = "INSERT INTO {$this->table} (ime, prezime, email, lozinka, uloga)
                VALUES (?, ?, ?, ?, 'korisnik')";
        $stmt = $this->conn->prepare($sql);
        $hashed = password_hash($lozinka, PASSWORD_DEFAULT);
        return $stmt->execute([$ime, $prezime, $email, $hashed]);
    }

    public function login($email, $lozinka) {
        $sql = "SELECT * FROM {$this->table} WHERE email = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($lozinka, $user['lozinka'])) {
            return $user;
        }
        return false;
    }
}
