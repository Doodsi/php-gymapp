<?php
require_once 'db.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

// Dodavanje trenera
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {
    $name = $_POST['name'];
    $specialty = $_POST['specialty'];

    $stmt = $pdo->prepare("INSERT INTO trainers (name, specialty) VALUES (?, ?)");
    $stmt->execute([$name, $specialty]);
    header("Location: trainers.php");
    exit();
}

// Brisanje trenera
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM trainers WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: trainers.php");
    exit();
}

// Dohvaćanje za edit
$editTrainer = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM trainers WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editTrainer = $stmt->fetch();
}

// Ažuriranje trenera
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $specialty = $_POST['specialty'];

    $stmt = $pdo->prepare("UPDATE trainers SET name = ?, specialty = ? WHERE id = ?");
    $stmt->execute([$name, $specialty, $id]);
    header("Location: trainers.php");
    exit();
}

// Popis svih trenera
$stmt = $pdo->query("SELECT * FROM trainers");
$trainers = $stmt->fetchAll();
?>

<h1>Treneri</h1>

<?php if ($editTrainer): ?>
    <form method="post">
        <input type="hidden" name="id" value="<?= $editTrainer['id'] ?>">
        Ime: <input type="text" name="name" value="<?= htmlspecialchars($editTrainer['name']) ?>" required>
        Specijalnost: <input type="text" name="specialty" value="<?= htmlspecialchars($editTrainer['specialty']) ?>">
        <input type="submit" name="update" value="Ažuriraj">
        <a href="trainers.php">Odustani</a>
    </form>
<?php else: ?>
    <form method="post">
        Ime: <input type="text" name="name" required>
        Specijalnost: <input type="text" name="specialty">
        <input type="submit" name="save" value="Dodaj trenera">
    </form>
<?php endif; ?>

<br>
<table border="1" cellpadding="8">
    <tr><th>Ime</th><th>Specijalnost</th><th>Akcija</th></tr>
    <?php foreach ($trainers as $trainer): ?>
        <tr>
            <td><?= htmlspecialchars($trainer['name']) ?></td>
            <td><?= htmlspecialchars($trainer['specialty']) ?></td>
            <td>
                <a href="?edit=<?= $trainer['id'] ?>">Uredi</a> |
                <a href="?delete=<?= $trainer['id'] ?>" onclick="return confirm('Obrisati trenera?')">Obriši</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<br>
<a href="dashboard.php">Natrag na raspored</a>


<hr>
<nav>
    <a href="dashboard.php">📋 Raspored</a> |
    <a href="trainers.php">🏋️‍♂️ Treneri</a> |
    <a href="user_trainer.php">🔗 Veze korisnik–trener</a> |
    <a href="add_workout.php">➕ Dodaj trening</a> |
    <a href="logout.php">🚪 Odjava</a>
</nav>

<br><br>
<a href="home.php">⬅️ Natrag na početnu</a>