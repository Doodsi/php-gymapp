<?php
session_start();
if (isset($_SESSION['user'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!--
<!DOCTYPE html>
<html>
<head>
    <title>Login - Gym App</title>
</head>
<body>
    <h2>Login</h2>
    <form method="post" action="login.php">
        Email: <input type="email" name="email" required><br><br>
        Lozinka: <input type="password" name="password" required><br><br>
        <input type="submit" value="Prijava">
    </form>
</body>
</html>
-->

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Prijava</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h2 class="mt-4">Prijava</h2>
    <?php if (!empty($message)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="POST" action="login_process.php">
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="lozinka" class="form-label">Lozinka</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary" value="Prijava">Prijava</button>
    </form>
</body>
</html>