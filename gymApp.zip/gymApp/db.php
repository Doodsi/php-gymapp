<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=gym_app", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Greška pri spajanju: " . $e->getMessage());
}
?>
