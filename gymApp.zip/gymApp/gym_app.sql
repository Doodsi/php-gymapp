-- Kreiranje baze
CREATE DATABASE IF NOT EXISTS gym_app;
USE gym_app;

-- Tablica korisnika
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tablica članarina
CREATE TABLE memberships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('monthly', 'yearly', 'trial') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tablica treninga
CREATE TABLE workouts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    workout_date DATE NOT NULL,
    description TEXT,
    duration_minutes INT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Dodavanje testnog korisnika
INSERT INTO users (name, email, password) VALUES
('Ivan Ivić', 'ivan@example.com', 'test123');

-- Test članarina
INSERT INTO memberships (user_id, type, start_date, end_date) VALUES
(1, 'monthly', '2025-06-01', '2025-06-30');

-- Test trening
INSERT INTO workouts (user_id, workout_date, description, duration_minutes) VALUES
(1, '2025-06-20', 'Full body workout', 60);


-- Tablica trenera
CREATE TABLE IF NOT EXISTS trainers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialty VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Primjer unosa trenera
INSERT INTO trainers (name, specialty) VALUES
('Ana Trenerica', 'Kondicijski trening'),
('Marko Trener', 'Snaga i masa');


-- Relacija: koji trener trenira kojeg korisnika
CREATE TABLE IF NOT EXISTS user_trainer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    trainer_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (trainer_id) REFERENCES trainers(id) ON DELETE CASCADE
);

-- Primjer povezivanja
INSERT INTO user_trainer (user_id, trainer_id, start_date, end_date) VALUES
(1, 1, '2025-06-01', '2025-06-30');
