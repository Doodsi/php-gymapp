<?php
require_once 'db.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

// Dodavanje nove veze korisnik-trener
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create'])) {
    $user_id = $_POST['user_id'];
    $trainer_id = $_POST['trainer_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $stmt = $pdo->prepare("INSERT INTO user_trainer (user_id, trainer_id, start_date, end_date) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $trainer_id, $start_date, $end_date]);
    header("Location: user_trainer.php");
    exit();
}

// Brisanje veze
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM user_trainer WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: user_trainer.php");
    exit();
}

// Dohvaćanje za edit
$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM user_trainer WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit = $stmt->fetch();
}

// Ažuriranje
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $id = $_POST['id'];
    $user_id = $_POST['user_id'];
    $trainer_id = $_POST['trainer_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $stmt = $pdo->prepare("UPDATE user_trainer SET user_id = ?, trainer_id = ?, start_date = ?, end_date = ? WHERE id = ?");
    $stmt->execute([$user_id, $trainer_id, $start_date, $end_date, $id]);
    header("Location: user_trainer.php");
    exit();
}

// Dohvati sve korisnike i trenere za odabir
$users = $pdo->query("SELECT id, name FROM users")->fetchAll();
$trainers = $pdo->query("SELECT id, name FROM trainers")->fetchAll();

// Dohvati sve veze
$stmt = $pdo->query("SELECT ut.id, u.name AS user_name, t.name AS trainer_name, ut.start_date, ut.end_date
                     FROM user_trainer ut
                     JOIN users u ON ut.user_id = u.id
                     JOIN trainers t ON ut.trainer_id = t.id");
$relations = $stmt->fetchAll();
?>

<h1>Povezivanje trenera i korisnika</h1>

<?php if ($edit): ?>
<form method="post">
    <input type="hidden" name="id" value="<?= $edit['id'] ?>">
    Korisnik:
    <select name="user_id" required>
        <?php foreach ($users as $u): ?>
            <option value="<?= $u['id'] ?>" <?= $edit['user_id'] == $u['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($u['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    Trener:
    <select name="trainer_id" required>
        <?php foreach ($trainers as $t): ?>
            <option value="<?= $t['id'] ?>" <?= $edit['trainer_id'] == $t['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($t['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    Od: <input type="date" name="start_date" value="<?= $edit['start_date'] ?>" required>
    Do: <input type="date" name="end_date" value="<?= $edit['end_date'] ?>">
    <input type="submit" name="update" value="Ažuriraj">
    <a href="user_trainer.php">Odustani</a>
</form>
<?php else: ?>
<form method="post">
    Korisnik:
    <select name="user_id" required>
        <?php foreach ($users as $u): ?>
            <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
        <?php endforeach; ?>
    </select>
    Trener:
    <select name="trainer_id" required>
        <?php foreach ($trainers as $t): ?>
            <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
        <?php endforeach; ?>
    </select>
    Od: <input type="date" name="start_date" required>
    Do: <input type="date" name="end_date">
    <input type="submit" name="create" value="Dodaj">
</form>
<?php endif; ?>

<br>
<table border="1" cellpadding="8">
    <tr><th>Korisnik</th><th>Trener</th><th>Od</th><th>Do</th><th>Akcije</th></tr>
    <?php foreach ($relations as $rel): ?>
        <tr>
            <td><?= htmlspecialchars($rel['user_name']) ?></td>
            <td><?= htmlspecialchars($rel['trainer_name']) ?></td>
            <td><?= htmlspecialchars($rel['start_date']) ?></td>
            <td><?= htmlspecialchars($rel['end_date']) ?></td>
            <td>
                <a href="?edit=<?= $rel['id'] ?>">Uredi</a> |
                <a href="?delete=<?= $rel['id'] ?>" onclick="return confirm('Obrisati ovu vezu?')">Obriši</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<br>
<a href="dashboard.php">Natrag</a>


<hr>
<nav>
    <a href="dashboard.php">📋 Raspored</a> |
    <a href="trainers.php">🏋️‍♂️ Treneri</a> |
    <a href="user_trainer.php">🔗 Veze korisnik–trener</a> |
    <a href="add_workout.php">➕ Dodaj trening</a> |
    <a href="logout.php">🚪 Odjava</a>
</nav>

<br><br>
<a href="home.php">⬅️ Natrag na početnu</a>