<?php
require_once 'config/database.php';
require_once 'classes/User.php';

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $database = new Database();
    $db = $database->connect();
    $user = new User($db);

    if ($user->register($_POST['ime'], $_POST['prezime'], $_POST['email'], $_POST['lozinka'])) {
        $message = "Uspješna registracija!";
    } else {
        $message = "Greška pri registraciji.";
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Registracija</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h2 class="mt-4">Registracija</h2>
    <form method="POST">
        <input class="form-control my-2" type="text" name="ime" placeholder="Ime" required>
        <input class="form-control my-2" type="text" name="prezime" placeholder="Prezime" required>
        <input class="form-control my-2" type="email" name="email" placeholder="Email" required>
        <input class="form-control my-2" type="password" name="lozinka" placeholder="Lozinka" required>
        <button class="btn btn-primary" type="submit">Registriraj se</button>
    </form>
    <p class="mt-3"><?= htmlspecialchars($message) ?></p>
</body>
</html>
