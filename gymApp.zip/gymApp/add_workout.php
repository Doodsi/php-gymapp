<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

require_once 'db.php';

$message = "";

// Handle form submission to add a new workout
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create'])) {
    $user_id = $_POST['user_id'];
    $trainer_id = $_POST['trainer_id'];
    $workout_date = $_POST['workout_date'];
    $description = $_POST['description'];
    $duration = $_POST['duration'];

    try {
        // Check if the user is linked to the trainer
        $stmt = $pdo->prepare("SELECT * FROM user_trainer WHERE user_id = ? AND trainer_id = ?");
        $stmt->execute([$user_id, $trainer_id]);
        $relation = $stmt->fetch();

        if ($relation) {
            // Insert the new workout
            $stmt = $pdo->prepare("INSERT INTO workouts (user_id, workout_date, description, duration_minutes) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $workout_date, $description, $duration]);
            $message = "✅ Trening uspješno dodan!";
        } else {
            $message = "❌ Korisnik nije povezan s odabranim trenerom.";
        }
    } catch (PDOException $e) {
        $message = "Greška: " . $e->getMessage();
    }
}

// Fetch users and trainers for the dropdowns
$users = $pdo->query("SELECT id, name FROM users")->fetchAll();
$trainers = $pdo->query("SELECT id, name FROM trainers")->fetchAll();
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj Trening</title>
</head>
<body>
    <h1>Dodaj Novi Trening</h1>

    <?php if (!empty($message)): ?>
        <div style="color: green;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="post" action="add_workout.php">
        <label for="user_id">Korisnik:</label>
        <select name="user_id" id="user_id" required>
            <option value="">Odaberi korisnika</option>
            <?php foreach ($users as $user): ?>
                <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['name']) ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="trainer_id">Trener:</label>
        <select name="trainer_id" id="trainer_id" required>
            <option value="">Odaberi trenera</option>
            <?php foreach ($trainers as $trainer): ?>
                <option value="<?= $trainer['id'] ?>"><?= htmlspecialchars($trainer['name']) ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="workout_date">Datum:</label>
        <input type="date" name="workout_date" id="workout_date" required><br><br>
        <label for="description">Opis:</label>
        <textarea name="description" id="description" rows="4" cols="50"></textarea><br><br>
        <label for="duration">Trajanje (min):</label>
        <input type="number" name="duration" id="duration" required><br><br>
        <button type="submit" name="create" value="create">Dodaj Trening</button>
        </form>

<br><a href="dashboard.php">⬅️ Povratak na Raspored</a>

</body>
</html>