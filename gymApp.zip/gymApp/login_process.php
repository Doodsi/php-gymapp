<?php
session_start();
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
 
        if ($user && $password === $user['password']) {
            $_SESSION['user'] = $user;
            header("Location: layout.php");
        } else {
            echo "Neispravni podaci za prijavu.";
        }
    } catch (PDOException $e) {
        echo "Greška: " . $e->getMessage();
    }
}
?>
